$(document).ready(function(){
    //alert('document is ready');
    $( ".draggable" ).draggable();
});